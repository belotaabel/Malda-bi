'use client'

const referenceImage =
  'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1788891773984-H35ZEisBwznG2ZnEmFH9yj92BFi1CJ.jpg'

const calls = Array.from({ length: 75 }, (_, index) => index + 1)

export default function GamePage() {
  return (
    <main className="game-shell">
      <div className="game-canvas">
        <img src={referenceImage} alt="Maleda Bingo live gameplay board" className="game-artwork" />
        <section className="game-hotspots" aria-label="Live bingo game controls">
          <div className="call-grid" aria-label="Bingo call board">
            {calls.map((number) => (
              <button key={number} type="button" className="call-hotspot" aria-label={`Call ${number}`}>
                <span className="sr-only">Call {number}</span>
              </button>
            ))}
          </div>
          <button type="button" className="live-control auto" aria-label="Toggle automatic play" />
          <button type="button" className="live-control sound" aria-label="Toggle sound" />
          <button type="button" className="live-control refresh" aria-label="Refresh game" />
          <a className="live-control leave" href="/play" aria-label="Leave live game" />
          <a className="player-card card-one" href="/winner" aria-label="Announce winner from board 318" />
          <a className="player-card card-two" href="/winner" aria-label="Announce winner from board 315" />
        </section>
      </div>
    </main>
  )
}
