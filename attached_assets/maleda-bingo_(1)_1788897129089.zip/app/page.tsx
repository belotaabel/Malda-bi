'use client'

const referenceImage =
  'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/88b3138f-23c9-4b8a-b228-e7deac00462c-TrpHWzeqGMbaj2MnMsdJk5Xd58jg1h.png'

const hotspots = [
  { label: 'Home', href: '#home', className: 'hotspot-home' },
  { label: 'Games', href: '#games', className: 'hotspot-games' },
  { label: 'Bonuses', href: '#bonuses', className: 'hotspot-bonuses' },
  { label: 'How to Play', href: '#how-to-play', className: 'hotspot-how-to-play' },
  { label: 'FAQ', href: '#faq', className: 'hotspot-faq' },
  { label: 'Play Now', href: '/play', className: 'hotspot-top-cta' },
  { label: 'Hero Play Now', href: '/play', className: 'hotspot-hero-cta' },
  { label: 'Join Now', href: 'https://t.me/maledabingo', className: 'hotspot-join-cta' },
  { label: 'Promo Code', href: '#bonuses', className: 'hotspot-promo-cta' },
  { label: 'Become an Agent', href: '#agent-program', className: 'hotspot-agent-cta' },
  { label: 'Start Playing', href: '/play', className: 'hotspot-start-cta' },
]

export default function Page() {
  return (
    <main className="landing-shell" id="home">
      <div className="landing-canvas">
        <img
          src={referenceImage}
          alt="Maleda Bingo landing page with bingo games, bonuses, and Telegram calls to action"
          className="reference-artwork"
        />
        <nav className="hotspot-layer" aria-label="Landing page navigation">
          {hotspots.map((hotspot) => (
            <a
              key={hotspot.label}
              href={hotspot.href}
              className={`visual-hotspot ${hotspot.className}`}
              aria-label={hotspot.label}
              target={hotspot.href.startsWith('http') ? '_blank' : undefined}
              rel={hotspot.href.startsWith('http') ? 'noreferrer' : undefined}
            >
              <span className="sr-only">{hotspot.label}</span>
            </a>
          ))}
        </nav>
      </div>
    </main>
  )
}
