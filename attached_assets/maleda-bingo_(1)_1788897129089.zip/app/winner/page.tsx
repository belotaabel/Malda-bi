'use client'

const referenceImage =
  'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/94432522-1b5d-4494-ab58-ef8520f50f26-GZlyw0dGNz6ZuLMxR9h0o5qcP96Uf5.png'

export default function WinnerPage() {
  return (
    <main className="winner-shell">
      <div className="winner-canvas">
        <img
          src={referenceImage}
          alt="Maleda Bingo winner announcement showing two winners and their prizes"
          className="winner-artwork"
        />
        <section className="winner-hotspots" aria-label="Winner announcement actions">
          <button type="button" className="winner-row winner-row-one" aria-label="View winner Anteenh and prize 2256 ETB">
            <span className="sr-only">Anteenh has won 2256 ETB</span>
          </button>
          <button type="button" className="winner-row winner-row-two" aria-label="View winner FOZISARdarI14 and prize 2256 ETB">
            <span className="sr-only">FOZISARdarI14 has won 2256 ETB</span>
          </button>
          <button type="button" className="winner-board board-one" aria-label="View board 217" />
          <button type="button" className="winner-board board-two" aria-label="View second winning card" />
          <a className="play-again" href="/play" aria-label="Play again">Play Again</a>
        </section>
      </div>
    </main>
  )
}
