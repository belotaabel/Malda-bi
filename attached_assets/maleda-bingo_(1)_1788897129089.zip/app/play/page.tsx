'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'

const referenceImage =
  'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/71db2d19-ec29-4c20-baef-1e2358ca38ea-zMJoilOgJvGbQ22zXvn1jtUCKXpDAr.png'

const numbers = Array.from({ length: 100 }, (_, index) => index + 261)

export default function PlayPage() {
  const router = useRouter()
  const [seconds, setSeconds] = useState<number | null>(null)

  useEffect(() => {
    if (seconds === null) return
    if (seconds === 0) {
      router.push('/game')
      return
    }
    const timer = window.setTimeout(() => setSeconds((value) => (value ?? 1) - 1), 1000)
    return () => window.clearTimeout(timer)
  }, [seconds, router])

  return (
    <main className="play-shell">
      <div className="play-canvas">
        <img src={referenceImage} alt="Maleda Bingo card selection game board" className="play-artwork" />
        <section className="play-hotspots" aria-label="Bingo card selection controls">
          <div className="number-grid" aria-label="Available bingo boards">
            {numbers.map((number) => (
              <button key={number} type="button" className="number-hotspot" aria-label={`Board ${number}`}>
                <span className="sr-only">Board {number}</span>
              </button>
            ))}
          </div>
          <button type="button" className="control-hotspot remove" aria-label="Remove selected card" />
          <button type="button" className="control-hotspot remove-all" aria-label="Remove all cards" />
          <button type="button" className="control-hotspot play" aria-label={seconds === null ? 'Start bingo game' : `Game starts in ${seconds} seconds`} onClick={() => setSeconds(7)}>
            {seconds !== null ? <span className="countdown-label">0:{seconds}</span> : null}
          </button>
          <a className="control-hotspot leave" href="/" aria-label="Leave game" />
        </section>
      </div>
    </main>
  )
}
